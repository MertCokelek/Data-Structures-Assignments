#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include <string.h>
Layer* initLayer() {    /* create a new layer for the stack. */
    Layer *root = NULL;
    return root;
}
Layer* push(Layer* root, char* s, char* r, char* m){ // s,r  = ID, IP... m = only mesChunk
    if(root == NULL){
        root = (Layer*)malloc(sizeof(Layer));
        root->messageChunk = (char*)malloc(sizeof(char) * (int)strlen(m));
        root->receiverInfo = (char*)malloc(sizeof(char) * (int)strlen(r));
        root->senderInfo = (char*)malloc(sizeof(char) * (int)strlen(s));
        strcpy(root->senderInfo, s);
        strcpy(root->receiverInfo, r);
        strcpy(root->messageChunk, m);
        root->nextLayer = NULL;
        root->prevLayer = NULL;
        return root;
    }
    Layer* iter = root;
    while(iter->nextLayer != NULL)
        iter = iter->nextLayer;
    Layer* temp = (Layer*)malloc(sizeof(Layer));

    temp->receiverInfo = (char*)malloc(sizeof(char) * (int)strlen(r));
    temp->senderInfo = (char*)malloc(sizeof(char) * (int)strlen(s));
    strcpy(temp->receiverInfo, r);
    strcpy(temp->senderInfo, s);
    iter->nextLayer = temp;
    temp->prevLayer = iter;
    temp->nextLayer = NULL;

    return root;
}
void Pop(Layer* root){
    if(root == NULL)
        return ;
    else if(root->nextLayer == NULL){
        root->messageChunk = NULL;
        root->senderInfo = NULL;
        root->receiverInfo = NULL;
        root = NULL;
        free(root);
        return ;
    }
    Layer* iter = root;
    while(iter->nextLayer->nextLayer != NULL)
        iter = iter->nextLayer;
    iter->senderInfo = NULL;
    iter->receiverInfo = NULL;
    iter->nextLayer = NULL;
    iter = NULL;
    free(iter);
}
void printStack(Layer* layer){
    int layerCounter = 0;
    while(layer->nextLayer != NULL)         /*To iter reverse over the stack, first going to the end of it.*/
        layer = layer->nextLayer;
    while (layer != NULL){                  /*Iterating reversely over the stack and printing the required infos.*/
        if(layerCounter == 0)
            printf("Sender MAC address: %s, Receiver MAC address: %s\n",layer->senderInfo, layer->receiverInfo);
        if(layerCounter == 1)
            printf("Sender IP address: %s, Receiver IP address: %s\n", layer->senderInfo, layer->receiverInfo);
        if(layerCounter == 2)
            printf("Sender port number: %s, Receiver port number: %s\n", layer->senderInfo, layer->receiverInfo);
        if(layerCounter == 3)
            printf("Sender ID: %s, Receiver ID: %s\nMessage chunk carried: %s\n", layer->senderInfo, layer->receiverInfo, layer->messageChunk);
        layerCounter++;
        layer = layer->prevLayer;
    }
    printf("--------\n"); layerCounter = 0;
}
