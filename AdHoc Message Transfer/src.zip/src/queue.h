#ifndef queue
#define queue

#include "stack.h"

typedef struct frame{
    struct layer* layer;
    char** LogMessage;  /* MAC, IP, PORT, CHUNK */
    int numberOfHops;
    struct frame* nextFrame;
}Frame;
void enque(Frame**root, struct layer* layer);
void deque(Frame* root);
Layer* Deque(Frame* root);
#endif