#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include "stack.h"
void enque(Frame** root, Layer* layer) {
    if (*root == NULL) {
        *root = (Frame *) malloc(sizeof(Frame));
        (*root)->layer = layer;
        (*root)->nextFrame = NULL;
        (*root)->numberOfHops = 0;
    }else{
        Frame *iter = *root;
        while (iter->nextFrame != NULL)
            iter = iter->nextFrame;
        Frame *temp = (Frame *) malloc(sizeof(Frame));
        temp->nextFrame = NULL;
        temp->layer = layer;
        iter->nextFrame = temp;
        iter->numberOfHops = (*root)->numberOfHops;
    }
}
Layer* Deque(Frame* root){
    if(root == NULL)
        return NULL;
    Layer* rLayer = root->layer;
    root = root->nextFrame;
    return rLayer;
}
