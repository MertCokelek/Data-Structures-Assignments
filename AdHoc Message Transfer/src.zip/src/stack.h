#ifndef stack
#define stack
struct layer{
    char* senderInfo;
    char* receiverInfo;
    char* messageChunk;
    struct layer* nextLayer;
    struct layer* prevLayer;
};
typedef struct layer Layer;
Layer* initLayer();
Layer* push(Layer* root, char* var1, char* var2, char* v3);
void printStack(Layer* layer);
void Pop(Layer* root);
#endif