#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "stack.h"
#include "queue.h"

typedef struct{
    char* ID;
    char* sPort;
    char* rPort;
    char* IP;
    char* MAC;
    char** routes;
    struct frame* incomingQueue;
    struct frame* outgoingQueue;
    int receiveSuccess;
    int forwardSuccess;
}client;
char** split(char* line, char* tok, int amount){                      /* Splits a given string into array by a token. */
    int i = 0; int tokenLen = 1001;                                  /*Used for reading files and splitting the lines.*/
    char* p = strtok(line, tok);
    char** array = (char**)malloc(sizeof(char*) * amount);
    for(i = 0; i < amount; i++){
        array[i] = (char*)malloc(sizeof(char) * (int)strlen(p) + tokenLen);
    }
    i = 0;
    while(p != NULL){
        strcpy(array[i++], p);
        p = strtok(NULL, tok);
    }
    return array;
}
char *splitIntoChunks(const char *str, size_t size){                             /* For splitting Message into chunks.*/
    static const char *p = NULL;
    char *temp;
    int i;
    if(str != NULL) p=str;
    if(p == NULL || *p == '\0')
        return NULL;
    temp = (char*)malloc((size+1)*sizeof(char));
    for(i = 0; *p && i < size ;++i)
        temp[i] = *p++;
    temp[i]='\0';
    return temp;
}

/*Getting routes and client informations from .dat files.*/
client* getClients(FILE* file, client* clientList, char* senPort, char* recPort){  /*Reading clients.dat, creating clients*/
    char buffer[22]; /* Every single line. */
    int i = 0, c = 0; /* i = line counter, c = client counter */
    int numOfClients = 0;
    while(fgets(buffer, 22, file)) {
        if(i == 0){   /*First line, so the line contains the total number of clients. */
            numOfClients = (int)strtol(buffer, (char **)NULL, 10);  /* Getting the number of clients with strtol. */
            clientList = (client*)malloc(sizeof(client) * numOfClients); /* Allocating memory for clients array. */
            i++;
        }else{
            char** splitted = split(buffer, " ", 3);  /*splitting the line into 3 elements, ID, IP, MAC*/

            /*deleting the \n character from the end of the MAC*/
            if(splitted[2][(int)strlen(splitted[2]) -1] == '\n')
                splitted[2][(int)strlen(splitted[2]) -1] = 0;

            clientList[c].ID = (char*)malloc(sizeof(char) * (int)strlen(splitted[0]));
            clientList[c].IP = (char*)malloc(sizeof(char) * (int)strlen(splitted[1]));
            clientList[c].MAC = (char*)malloc(sizeof(char) * (int)strlen(splitted[2]));
            clientList[c].sPort = (char*)malloc(sizeof(char) * (int)strlen(senPort));
            clientList[c].rPort = (char*)malloc(sizeof(char) * (int)strlen(recPort));
            clientList[c].outgoingQueue = NULL;
            clientList[c].incomingQueue = NULL;
            clientList[c].receiveSuccess = 1;
            clientList[c].forwardSuccess = 1;
            strcpy(clientList[c].ID,splitted[0]);
            strcpy(clientList[c].IP, splitted[1]);
            strcpy(clientList[c].MAC, splitted[2]);
            strcpy(clientList[c].sPort, senPort);
            strcpy(clientList[c].rPort, recPort);
            c++;
        }
    }
    return clientList;
}
void getRoutes(FILE* file, client* clientList, int numOfClients){
    char line[6];
    int cCounter = 0; /* The client counter */
    int rCounter = 0; /* One Client's route counter.*/
    int i, j;         /* Used in for loops. */

    /*Allocate memory for the clients' routes.*/
    for(i = 0; i < numOfClients; i++){
        clientList[i].routes = (char**)malloc(sizeof(char*) * numOfClients-1);
        for(j = 0; j < numOfClients-1; j++){
            clientList[i].routes[j] = (char*)malloc(sizeof(char) *10);
        }
    }

    /*Read the routes file and store the routes of the clients, the delimeter is '-' character.*/
    while(fgets(line, 6, file)){

        if(line[0] != '-'){  /* Work on the same client until seeing a '-'. */
            if(line[strlen(line)-1] == '\n')
                line[strlen(line)-1] = 0;
            strcpy(clientList[cCounter].routes[rCounter], line);
            rCounter += 1;
        }else{   /* If the line is '-', then get to the next client. */
            rCounter = 0;
            cCounter += 1;
        }
    }
}

/*For the Message command, MESSAGE function.*/
void MESSAGE(client* clientList, client* sender, char** transferPart, char* message, int maxSize, int numberOfClients){
    int i,j; /* These variables are used as counters in for loops */
    int numOfTotalChunks = ((int)ceil((float)strlen(message) /(maxSize)));  /* MessageLen / MaxSize */
    char** messageChunk = (char**)malloc(sizeof(char*) *numOfTotalChunks);  /* Allocating memory for the chunk string. */

    for(i = 0; i < numOfTotalChunks; i++)                                   /* Allocate inside the chunk variable. */
        messageChunk[i] = (char*)malloc(sizeof(char) * maxSize);

    /*The receiver and transporter clients.*/
    client receiver;
    client transporter;  /* These will be filled if the correct ID's are found on the list and the routes. */

    for(i = 0; i < numberOfClients; i++){                           /* Choosing the correct clients for transporting. */
        if(strcmp(clientList[i].ID, transferPart[1]) == 0)              /*transferpart : e.g MESSAGE C E*/
            *sender = clientList[i];

        if(strcmp(clientList[i].ID, transferPart[2]) == 0)
            receiver = clientList[i];
    }

    char nextDestinationID = 0;                       /* For finding the next Destination from the sender's route. */

    for(i = 0; i < numberOfClients-1; i++){     /* Iterating over the sender's routes to find the next Destination */
        if(sender->routes[i][0] == receiver.ID[0])   /* Check for ID matching. */
            nextDestinationID = sender->routes[i][2];  /*If ID's match, then the next destination is here.*/
    }
    if(nextDestinationID != 0){                         /*In case of drop, checking.*/
        for(i = 0; i < numberOfClients; i++){
            if(clientList[i].ID[0] == nextDestinationID)
                transporter = clientList[i];
        }
    }

    /* Iterate until getting the last chunk. */
    for(i = 0; (message = splitIntoChunks(message, (size_t)maxSize)) != NULL; message = NULL)
        messageChunk[i++]=message;

    /*i is the total num of chunks here.*/
    for(j = 0; j < i; ++j){    /* j for the index of message chunks, i for the max number of message chunks */

        /* Frame is created as a stack.*/
        Layer* frame = initLayer();

        /* Layers are pushed into the stack. */
        frame = push(frame, sender->ID, receiver.ID, messageChunk[j]);          /*Application Layer pushed.*/
        frame = push(frame, sender->sPort, receiver.rPort, NULL);       /*Transport Layer pushed.*/
        frame = push(frame, sender->IP, receiver.IP, NULL);             /*Network Layer pushed.*/
        frame = push(frame, sender->MAC, transporter.MAC, NULL);        /*Physical Layer pushed.*/

        /* The completed frames are enqueued into the sender's outgoing queue. */
        enque(&(sender->outgoingQueue), frame);
        printf("Frame #%d\n", j+1);
        printStack(frame);
        free(messageChunk[j]); /* For health of memory, freeing the used variables. */
    }
}

/*For the Send command, the 5 functions below are defined.*/
client* findReceiver(client* clientList, client* sender, int numberOfClients){
    /* Finds the correct receiver of the message for the send func. */
    int i;  /* Used in for loop. */
    char* receiverID = sender->outgoingQueue->layer->receiverInfo;
    for(i = 0; i < numberOfClients; i++){
        if(strcmp(receiverID, clientList[i].ID) == 0)  /* If the ID's match, then this is the correct receiver. */
            return &(clientList[i]);
    }
    return NULL;   /*If the ID does not match in the list, then return NULL */
}
client* findNextDestination(client* clientList, client* sender, int numberOfClients){
    /* Finds the next destination of the message, for the send function. */
    int i;
    char* araciID = NULL;  /*Aracı = The next destination for forwarding the message.*/

    for(i = 0; i < numberOfClients-1; i++){   /* Iterating over the sender's route to find the address. */
        char** route = split(sender->routes[i], " ", 2); /* splitting route line, so we can get elements easily.*/

        /* in case of matching id's, getting the 'araci's ID. */
        if(strcmp(sender->outgoingQueue->layer->receiverInfo, route[0]) == 0)
            araciID = route[1];
    }

    for(i = 0; i < numberOfClients; i++){                    /*Finding the correct 'araci' from the client list by ID.*/
        if(araciID[0] ==  clientList[i].ID[0])
            return &(clientList[i]);
    }
    return NULL;  /*If the Aracı does not exist, return NULL*/
}
void makeForward(client* transporter, client* newTransporter){
    /* If the sender does not have direct access to the receiver, the MAC addresses of the app layer is modified here.*/
    Frame* iter = transporter->outgoingQueue;
    int i = 1;
    while(iter != NULL){
        Pop(iter->layer); /* Remove the old Data Link Layer. */
        /* Add new Data Link Layer */
        iter->layer = push(iter->layer, transporter->MAC, newTransporter->MAC, NULL);
        iter = iter->nextFrame;
        printf("\tFrame #%d MAC address change: New sender MAC %s, new receiver MAC %s\n",i++, transporter->MAC, newTransporter->MAC);
    }
}
Frame* transfer(client* sender, client* nextDest) {     /* Makes transport of queues by deque and enque functions.*/
    Frame *iter = sender->outgoingQueue;                /* Iterator for the frames of the first queue. */
    while (iter!= NULL){
        enque(&nextDest->incomingQueue, Deque(iter));   /* Making transport of frames from one queue to another. */
        iter = iter->nextFrame;
    }

    return nextDest->incomingQueue;

}
int SEND(client* clientList, client* sender, client* araci, client* receiver, int numberOfClients, int* numberOfHops){
    *numberOfHops += 1;
    araci->receiveSuccess = 1;
    sender->forwardSuccess = 1;
    receiver->receiveSuccess = 1;
    if(receiver->ID == araci->ID){    /*BASE CASE, 'next destination' = receiver. Transfer and stop.*/
        receiver->incomingQueue = transfer(sender, receiver);
        receiver->incomingQueue->numberOfHops = *numberOfHops;
        return 1;
    }else{        /*RECURSIVE CASE, Transfer until finding the correct receiver.*/
        araci->incomingQueue = transfer(sender, araci); /* enque the araci's incoming queue with the sender's outgoing*/
        araci->incomingQueue->numberOfHops = *numberOfHops;

        araci->outgoingQueue = transfer(araci, araci);  /* copy araci's incoming queue to its outgoing queue for next transfer.*/
        araci->outgoingQueue->numberOfHops = araci->incomingQueue->numberOfHops;

        printf("A message received by client %s, but intended for client %s. Forwarding...\n", araci->ID, receiver->ID);

        client* newAraci = findNextDestination(clientList, araci, numberOfClients); /* The new Aracı for the next transfer operation. */

        if(newAraci != NULL)
            makeForward(araci, newAraci);
        else {
            printf("Error: Unreachable destination. Packets are dropped after %d hops!\n", *numberOfHops);
            araci->forwardSuccess = 0;
            return 0;
        }
        /*RECURSION*/
        return SEND(clientList, araci, newAraci, receiver, numberOfClients, numberOfHops);
    }
}
void readCommands(FILE* file, client* clientList, int maxSize, int numberOfClients){     /* Reading Commands.dat, processing the commands. */
    char line[1100];
    int THERE_IS_A_ROUTE = 1; /* In Message Command, if the client does not have a link to the receiver, the frames will not be created. */
    int transferStarted = 0;  /* This will be True when Send command is active. */
    int lineCounter = 0;      /* For the total number of commands. */
    char* message = NULL;     /* This will be filled in Message command. */
    client sender;
    char* senderId = NULL;    /* For printLog command*/
    char* receiverId = NULL;
    while(fgets(line, 1100, file)) {
        char **currentLine;
        if(lineCounter != 0){  /* If the current line is not the first one, print the commands to the screen. */
            int lineLen = (int)strlen(line), i;
            if(lineLen > 110)
                lineLen = 110;
            for(i = 0; i < lineLen+9; i++)
                printf("-");
            if(line[strlen(line)-1] == '\n')
                line[strlen(line)-1] = 0;
            printf("\nCommand: %s\n", line);

            for(i = 0; i < lineLen+9; i++)
                printf("-");
            printf("\n");
        }

        if (strstr(line, "MESSAGE")) {                              /*MESSAGE COMMAND EXECUTED.*/
            int i;
            char **transferPart;                    /* The line, except the message part.*/
            currentLine = split(line, "#", 3);      /* Split the line into 2 parts, message and transfer part. */
            transferPart = split(currentLine[0], " ", 3);
            senderId = transferPart[1];
            receiverId = transferPart[2];
            message = currentLine[1];       /*The message between hashtags, splitted and stored in message string.*/

            printf("Message to be sent: %s\n\n", message);

            for(i = 0; i < numberOfClients; i++){       /*If the ID in the commands line and the client list, then the correct sender is found.*/
                if(clientList[i].ID[0] == transferPart[1][0])
                    sender = clientList[i];
            }
            for(i = 0; i < numberOfClients - 1; i++){
                if(sender.routes[i][0] == receiverId[0]){
                    if(sender.routes[i][2] == '-')      /* If the sender's routes does not have a link to the receiver, then don't create any frames.*/
                        THERE_IS_A_ROUTE = 0;
                }
            }

            for (i = 0; i < numberOfClients; i++)          /*If the ID in the commands line and the client list, then the correct receiver is found.*/
                if (clientList[i].ID[0] == transferPart[1][0]) {
                    if (THERE_IS_A_ROUTE)    /* If there is a route, then create frames and wait for the send command.*/
                        MESSAGE(clientList, &clientList[i], transferPart, message, maxSize, numberOfClients); /* The message func. called. */
                    else
                        printf("The message does not have a receiver. Frames are not created.\n");
                }

        } else if (strstr(line, "SHOW_FRAME_INFO")) {             /* SHOW FRAME INFO COMMAND EXECUTED. */
            currentLine = split(line, " ", 4);  /*Splitting the command line by spaces.*/
            /*assigning the required variables to the line elements.*/

            char queueType = currentLine[2][0];

            int frameNumber = (int) strtol(currentLine[3], (char **) NULL, 10); /* Type conversion in base10. */
            int i; /*for loop counter.*/

            client c; /*The client, which has the frame currently. */
            for (i = 0; i < numberOfClients; i++) { /*Iterating over client list to find the correct client.*/
                if (strcmp(clientList[i].ID, currentLine[1]) == 0)
                    c = clientList[i];
            }
            if (queueType == 'o') {            /* In case 'outgoing queue' */
                if (c.outgoingQueue != NULL && frameNumber <= (int)ceil((float)strlen(message) /(maxSize)) && frameNumber > 0) {
                    printf("Current Frame #%d on the outgoing queue of client %s\n", frameNumber, currentLine[1]);
                    Frame *iter = c.outgoingQueue;
                    for (i = 1; i < frameNumber; i++)
                        iter = iter->nextFrame;
                    printf("Carried Message: \"%s\"\n", iter->layer->messageChunk);
                    printf("Layer 0 info: Sender ID: %s, Receiver ID: %s\n", iter->layer->senderInfo, iter->layer->receiverInfo);
                    printf("Layer 1 info: Sender port number: %s, Receiver port number: %s\n",iter->layer->nextLayer->senderInfo, iter->layer->nextLayer->receiverInfo);
                    printf("Layer 2 info: Sender IP adress: %s, Receiver IP address: %s\n",iter->layer->nextLayer->nextLayer->senderInfo, iter->layer->nextLayer->nextLayer->receiverInfo);
                    printf("Layer 3 info: Sender MAC address: %s, Receiver MAC address: %s\n",iter->layer->nextLayer->nextLayer->nextLayer->senderInfo,iter->layer->nextLayer->nextLayer->nextLayer->receiverInfo);
                    printf("Number of hops so far: %d\n", c.outgoingQueue->numberOfHops);
                } else /*If there is no frame.*/
                    printf("No such frame.\n");

            } else if (queueType == 'i') {              /*In case 'incoming queue.'*/

                if(c.ID[0] == senderId[0])              /* If the client is the sender, then it will not have any frames.*/
                    printf("No such frame.\n");

                else if (c.incomingQueue != NULL &&frameNumber <= (int)ceil((float)strlen(message) /(maxSize)) && frameNumber > 0) {
                    printf("Current Frame #%d on the incoming queue of client %s\n", frameNumber, currentLine[1]);
                    Frame *iter = c.incomingQueue;
                    for (i = 1; i < frameNumber; i++)
                        iter = iter->nextFrame;
                    printf("Carried Message: %s\n", iter->layer->messageChunk);
                    printf("Layer 0 info: Sender ID: %s, Receiver ID:  %s\n", iter->layer->senderInfo, iter->layer->receiverInfo);
                    printf("Layer 1 info: Sender port number: %s, Receiver port number:  %s\n",iter->layer->nextLayer->senderInfo, iter->layer->nextLayer->receiverInfo);
                    printf("Layer 2 info: Sender IP: %s, Receiver IP:  %s\n", iter->layer->nextLayer->nextLayer->senderInfo,iter->layer->nextLayer->nextLayer->receiverInfo);
                    printf("Layer 3 info: Sender MAC: %s, Receiver MAC:  %s\n",iter->layer->nextLayer->nextLayer->nextLayer->senderInfo,iter->layer->nextLayer->nextLayer->nextLayer->receiverInfo);
                    printf("Number of hops so far: %d\n", c.incomingQueue->numberOfHops);

                } else
                    printf("No such frame.\n");
            }
        } else if (strstr(line, "SHOW_Q_INFO")) {                  /* SHOW Q INFO COMMAND EXECUTED. */
            currentLine = split(line, " ", 3);     /* Splitting the command line by space to assign to the variables. */
            client c;
            char *clientID = currentLine[1];
            char queueType = currentLine[2][0];
            int i;
            for (i = 0; i < numberOfClients; i++) {           /*Finding the correct client by ID.*/
                if (strcmp(clientList[i].ID, clientID) == 0)
                    c = clientList[i];
            }
            if (queueType == 'o') {                /* Outgoing queue case */
                printf("Client %s Outgoing Queue Status\n", c.ID);
                if (c.outgoingQueue == NULL)
                    printf("Current total number of frames: 0\n");
                else {
                    int frameCounter = 1;
                    Frame *iter = c.outgoingQueue;
                    while (iter->nextFrame != NULL) {
                        iter = iter->nextFrame;
                        frameCounter += 1;
                    }
                    printf("Current total number of frames: %d\n", frameCounter);
                }
            } else if (queueType == 'i') {                  /*Incoming queue case*/
                printf("Client %s Incoming Queue Status\n", c.ID);
                if (c.incomingQueue == NULL)
                    printf("Current total number of frames: 0\n");
                else {
                    int frameCounter = 1;
                    Frame *iter = c.incomingQueue;
                    while (iter->nextFrame != NULL) {
                        iter = iter->nextFrame;
                        frameCounter += 1;
                    }
                    printf("Current total number of frames: %d\n", frameCounter);
                }
            }
        }else if(strstr(line, "SEND")){                                 /*SEND COMMAND EXECUTED.*/
            if(THERE_IS_A_ROUTE){
                int i;
                char** splitted = split(line, " ", 2);
                for(i = 0; i < numberOfClients; i++){                             /*Finding the correct client to send from.*/
                    if(clientList[i].ID[0] == splitted[1][0]){
                        char* recID = findReceiver(clientList, &clientList[i], numberOfClients)->ID;
                        int numberOfHops = 0;
                        client* receiver = findReceiver(clientList, &clientList[i], numberOfClients); /*Finding the correct receiver of the message.*/
                        client* araci = findNextDestination(clientList, &clientList[i], numberOfClients);

                        transferStarted = 1;
                        if(SEND(clientList, &(clientList[i]), araci, receiver,  numberOfClients, &numberOfHops)) {
                            printf("A message received by client %s from client %s after a total of %d hops\n", recID,clientList[i].ID, numberOfHops);
                            printf("Message: %s\n", message);
                        }
                    }
                }
            }else{
                printf("The message can't be sent because it does not have a receiver.\n");
            }

        }else if(strstr(line, "PRINT_LOG")){
            time_t  t = time(NULL);

            struct tm tm = *localtime(&t);
            char** splitted = split(line, " ", 2);
            char* clientID = splitted[1];
            if(clientID[strlen(clientID)-1] == '\n')
                clientID[strlen(clientID)-1] = 0;
            int i;
            for(i = 0; i < numberOfClients; i++){
                if(strcmp(clientList[i].ID, clientID) == 0){        /* Finding correct client to show log. */
                    printf("Client %s Logs:\n--------------\n", clientList[i].ID);
                    int entryCounter = 1;
                    if(clientList[i].incomingQueue != NULL){
                        printf("Log Entry #%d:\n", entryCounter++);
                        printf("Timestamp: %d-%d-%d %d:%d:%.2d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
                        printf("Message: %s\n", message);
                        int numOfFrames = 0;
                        Frame* iter = clientList[i].incomingQueue;
                        while(iter != NULL){
                            numOfFrames+=1;
                            iter = iter->nextFrame;
                        }
                        printf("Number of frames: %d\n", numOfFrames);
                        printf("Number of hops: %d\n", clientList[i].incomingQueue->numberOfHops);
                        printf("Sender ID: %s\nReceiver ID: %s\n", senderId, receiverId);
                        printf("Activity: Message Received.\n");
                        if(clientList[i].receiveSuccess) printf("Success: Yes\n"); else printf("Success: No\n");
                        printf("--------------\n");
                    }
                    if(clientList[i].outgoingQueue != NULL ) {

                        printf("Log Entry #%d:\n", entryCounter);
                        printf("Timestamp: %d-%d-%d %d:%d:%.2d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
                               tm.tm_hour, tm.tm_min, tm.tm_sec);
                        printf("Message: %s\n", message);
                        int numberOfFrames = 0;
                        Frame *iter = clientList[i].outgoingQueue;
                        while (iter != NULL) {
                            numberOfFrames++;
                            iter = iter->nextFrame;
                        }
                        printf("Number of frames: %d\n", numberOfFrames);
                        if (transferStarted == 1) {
                            printf("Number of hops: %d\n", clientList[i].outgoingQueue->numberOfHops);
                            printf("Sender ID: %s\nReceiver ID: %s\n", senderId, receiverId);
                            if (strcmp(clientID, senderId) == 0) printf("Activity: Message Sent.\n");
                            else printf("Activity: Message Forwarded.\n");
                            if (clientList[i].forwardSuccess) printf("Success: Yes\n"); else printf("Success: No\n");
                        }else{
                            printf("The transfer has not started yet. For now, the outgoingQueue of client %s is created and waiting for 'SEND' command.\n", clientID);
                            printf("Sender ID: %s\nReceiver ID: %s\n", senderId, receiverId);
                            if (strcmp(clientID, senderId) == 0) printf("Activity: Waiting for sending.\n");
                            else printf("Activity: Waiting for forwarding.\n");
                        }
                    }
                    if(clientList[i].outgoingQueue == NULL && clientList[i].incomingQueue == NULL)
                        printf("No log entry yet.\n");
                }
            }
        }
        else{
            if(lineCounter != 0)
                printf("Invalid Command.\n");
        }
        lineCounter++;
    }
}
int main(int argc, char* argv[]){
    FILE* clientsFile = fopen(argv[1], "r");
    FILE* routesFile = fopen(argv[2], "r");
    FILE* commandsFile = fopen(argv[3], "r");
    int maxSize = (int)strtol(argv[4], (char **)NULL, 10);

    char* senderPort = (char*)malloc(sizeof(char) *2* (int)strlen(argv[5]));
    char* receiverPort = (char*)malloc(sizeof(char) *2* (int)strlen(argv[6]));
    strcpy(senderPort, argv[5]);
    strcpy(receiverPort, argv[6]);

    client* clientList = NULL;
    int numberOfClients; fscanf(clientsFile, "%d" ,&numberOfClients);
    clientList = getClients(fopen(argv[1], "r"), clientList, senderPort, receiverPort);
    getRoutes(routesFile, clientList, numberOfClients);
    readCommands(commandsFile, clientList, maxSize, numberOfClients);

    fclose(clientsFile);
    fclose(commandsFile);
    fclose(routesFile);

    return 0;
}
