#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cstring>
using namespace std;
struct goal{
    string awayTeam;
    int minOfGoal, matchID;
    goal *gNext, *gPrev;    // The next and prev pointers for linked list.

    // Constructors.
    goal()
    : awayTeam(""),
    minOfGoal(-1),
    matchID(-1),
    gNext(nullptr),
    gPrev(nullptr){}

    goal(string awayTeam, int minOfGoal, int matchID, goal* gNext, goal* gPrev)
    :awayTeam(awayTeam),
    minOfGoal(minOfGoal),
    matchID(matchID),
    gNext(gNext),
    gPrev(gPrev){}
};
struct footballer{
    string name, teamName;
    goal* GoalList;  // Pointer of the "Goals Linked List" of the footballer.
    footballer* nextFootballer; // The next pointer for linked list.

    //Constructors
    footballer():
    name(""),
    teamName(""),
    GoalList(nullptr),
    nextFootballer(nullptr)
    {}

    footballer(string n, string tn, goal* g, footballer* f) :
    name(n),
    teamName(tn),
    nextFootballer(f),
    GoalList(g)
    {}
};
goal* insertGoal(goal* root, goal* newGoal){
    if(root == nullptr){                                         // If no goal defined before, create a new Linked List.
        root = new goal(newGoal->awayTeam, newGoal->minOfGoal, newGoal->matchID, nullptr, nullptr);
        return root;
    }else if(root->matchID > newGoal->matchID){     // If we need to add to head, since matchID is less than the head's.
        goal* newRoot = new goal(newGoal->awayTeam, newGoal->minOfGoal, newGoal->matchID, root, nullptr);
        root->gPrev = newRoot;
        return newRoot;
    }else{                                                                           // Add to the end or to the middle.
        goal* iter = root;                                // Iterating over the Linked List to find the place to insert.
        goal* newElem = new goal;                                               // The new goal, which will be inserted.

        newElem->matchID = newGoal->matchID;
        newElem->minOfGoal = newGoal->minOfGoal;
        newElem->awayTeam = newGoal->awayTeam;

        while(iter->gNext != nullptr && iter->gNext->matchID < newGoal->matchID)    // Find the place to insert orderly.
            iter = iter->gNext;

        if(iter->gNext == nullptr){                                             // The goal will be inserted to the end.
            iter->gNext = newElem;
            newElem->gPrev = iter;
            newElem->gNext = nullptr;
            return root;

        }else{                                                  // The goal will be inserted in somewhere in the middle.
            newElem->gNext = iter->gNext;
            iter->gNext->gPrev= newElem;
            iter->gNext = newElem;
            newElem->gPrev= iter;
            return root;
        }
    }
}
footballer* insertFootballer(footballer* root, string name, string teamName, goal* goal){
    if(root == nullptr){                              // If Linked List is empty, create a new footballer and return it.
        root = new footballer(name, teamName, goal, nullptr);
        return root;
    }else if(root->name == name){             // If the footballer has been registered before and has the smallest name.
        root->GoalList = insertGoal(root->GoalList, goal);
        return root;
    }else if(root->name > name){        // If the new footballer's name is smaller than the head's name, add it to head.
        footballer* newRoot = new footballer(name, teamName, goal, root);
        return newRoot;
    }else{                                                             // If we need to insert in the middle or the end.
        footballer* iter = root;                        // Iterate over the linked list to find a suitable place to add.

        while(iter->nextFootballer != nullptr && iter->nextFootballer->name < name)
            iter = iter->nextFootballer;

        footballer* temp;
        if(iter->nextFootballer == nullptr){                                 // Inserting at the end of the Linked List.
            temp = new footballer(name, teamName, goal, nullptr);
            temp->nextFootballer = nullptr;
            iter->nextFootballer = temp;
        }else if(iter->nextFootballer->name == name) { // If the footballer is registered before, just update goal list.
            temp = iter->nextFootballer;
            temp->GoalList = insertGoal(temp->GoalList, goal);
        }else{                                                                               // Inserting in the middle.
            temp = new footballer(name, teamName, goal, nullptr);
            temp->nextFootballer= iter->nextFootballer;
            iter->nextFootballer= temp;
        }
        return root;
    }
}
footballer* readInputFile(fstream &inputFile, footballer* footballers){
    string line;                                                                      // Holds the current line in file.
    string currentFootballer[5];                     // This array holds name, team name, match id, goal min, away team.
    int m = 0; int footballerCounter = 0;                       // m = index of the fields of the footballer. Maximum 5.

    while(getline(inputFile,line)){
        std::stringstream linestream(line);                                                   // Read file line by line.
        std::string token;                                                            // The tokenized part of the line.
        while(getline(linestream, token, ','))                                                  // split line by commas.
            currentFootballer[m++] = token;                                  // Initialize the fields of the footballer.
        goal* Goal = new goal(currentFootballer[2], std::stoi(currentFootballer[3]), std::stoi(currentFootballer[4]), nullptr, nullptr);
        if(footballerCounter == 0)                                                 // Create the footballer linked list.
            footballers = new footballer(currentFootballer[0], currentFootballer[1], Goal, nullptr);
        else                                                                  // Add new footballers to the linked list.
            footballers = insertFootballer(footballers, currentFootballer[0], currentFootballer[1], Goal);
        m = 0;  footballerCounter++;
    }return footballers;
}
int printHattrick(goal* g){
    int lastID = g->matchID;
    int goals = 0;
    while(g != nullptr){
        if(lastID == g->matchID)
            goals++;
        lastID = g->matchID;
        g = g->gNext;
    }
    if(goals >= 3)
        return 1;
    return 0;
}
int getNumberOfGoals(goal* g){
    int goals = 0;
    while(g != nullptr){
        goals++;
        g = g->gNext;
    }
    return goals;
}
void printOutput(footballer* Footballers, ofstream &outputFile){
    int goalsInFirstHalf = 0, goalsInSecondHalf = 0, mostScoredHalf = 0;
    string topScorer;
    footballer* iter = Footballers;
    string teams;
    string hatTricks;
    int maxGoal = 0;
    while(iter != nullptr){
        goal* iterG = iter->GoalList;
        string currentTopScorer;
        int currentNumOfGoals = 0;                                                                                  // 3
        while(iterG != nullptr){
            if(iterG->minOfGoal <= 45) goalsInFirstHalf++;                                                 // 1
            if(iterG->minOfGoal >= 46) goalsInSecondHalf++;
            currentNumOfGoals++;                                                                                    // 3

            if(!strstr(teams.c_str(), iter->teamName.c_str())){                                                     // 4
                teams.append(iter->teamName);
                teams.append("\n");}
            iterG = iterG->gNext;
        }
        if(currentNumOfGoals > maxGoal) maxGoal = currentNumOfGoals;
        iter = iter->nextFootballer;
    }
    if(goalsInFirstHalf < goalsInSecondHalf) mostScoredHalf = 1;
    if(goalsInFirstHalf > goalsInSecondHalf) mostScoredHalf = 0;
    if(goalsInFirstHalf == goalsInSecondHalf) mostScoredHalf = -1;

    iter = Footballers;
    while(iter != nullptr){
        if(getNumberOfGoals(iter->GoalList) == maxGoal){
            topScorer.append(iter->name);
            topScorer.append("\n");
        }
        iter = iter->nextFootballer;
    }
    outputFile << "1)THE MOST SCORED HALF\n" << mostScoredHalf << endl;
    outputFile << "2)GOAL SCORER\n" << topScorer ;
    outputFile << "3)THE NAMES OF FOOTBALLERS WHO SCORED HAT-TRICK\n";
    footballer* footballers = Footballers;
    while(footballers != nullptr){
        if(printHattrick(footballers->GoalList) == 1)
            outputFile << footballers->name << endl;
        footballers = footballers->nextFootballer;
    }
    outputFile << "4)LIST OF TEAMS\n" << teams;
    outputFile << "5)LIST OF FOOTBALLERS\n";
    iter = Footballers;
    while(iter != nullptr){
        outputFile << iter->name << endl;
        iter = iter->nextFootballer;
    }
}
footballer* getFootballerByName(string name, footballer* Footballers){
    if(Footballers != nullptr && Footballers->name == name)
        return Footballers;
    return getFootballerByName(name, Footballers->nextFootballer);
}
void printMatchesOfFootballer(footballer f, ofstream &outputFile){
    outputFile << "Matches of " << f.name <<endl;
    while(f.GoalList != nullptr){
        outputFile << "Footballer Name: " << f.name << ",Away Team: " << f.GoalList->awayTeam << ",Min of Goal: " << f.GoalList->minOfGoal << ",Match ID: " <<  f.GoalList->matchID << endl;
        f.GoalList = f.GoalList->gNext;
    }
}
void ascendingOrderAccordingToMatchID(footballer f, ofstream &outputFile){
    int lastID = -1;
    while(f.GoalList != nullptr) {
        if(lastID != f.GoalList->matchID)
            outputFile << "footballer Name: " << f.name << ",Match ID: " << f.GoalList->matchID << endl;
        lastID = f.GoalList->matchID;
        f.GoalList = f.GoalList->gNext;
    }
}
void descendingOrderAccordingToMatchID(footballer f, ofstream &outputFile){
    while(f.GoalList->gNext != nullptr)
        f.GoalList = f.GoalList->gNext;

    int lastID = -1;
    while(f.GoalList != nullptr) {
        if(lastID != f.GoalList->matchID)
            outputFile << "footballer Name: " << f.name << ",Match ID: " << f.GoalList->matchID << endl;
        lastID = f.GoalList->matchID;
        f.GoalList = f.GoalList->gPrev;
    }
}
void readOperations(fstream &operationsFile, footballer* footballers, ofstream &outputFile){
    string line;
    int lineCounter = 6;
    while(getline(operationsFile,line)){
        std::stringstream linestream(line);
        std::string value;
        if(lineCounter == 6) outputFile << "6)MATCHES OF GIVEN FOOTBALLER\n";
        if(lineCounter == 7) outputFile << "7)ASCENDING ORDER ACCORDING TO MATCH ID" << endl;
        if(lineCounter == 8) outputFile << "8)DESCENDING ORDER ACCORDING TO MATCH ID" << endl;
        while(getline(linestream,value,',')){
            if(lineCounter == 6) printMatchesOfFootballer(*getFootballerByName(value, footballers), outputFile);
            if(lineCounter == 7) ascendingOrderAccordingToMatchID(*getFootballerByName(value, footballers), outputFile);
            if(lineCounter == 8) descendingOrderAccordingToMatchID(*getFootballerByName(value, footballers), outputFile);
        }
        lineCounter++;
    }
}
int main(int argc, char** argv) {
    fstream inputFile(argv[1]);
    fstream operationsFile(argv[2]);
    ofstream outputFile(argv[3]);
    footballer* f1 = readInputFile(inputFile, f1);
    printOutput(f1, outputFile);
    readOperations(operationsFile, f1, outputFile);

    return 0;
}
